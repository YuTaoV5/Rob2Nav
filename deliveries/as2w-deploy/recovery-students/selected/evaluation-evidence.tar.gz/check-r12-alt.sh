#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export PYTHONPATH="$PWD/deps" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
py=/root/gpufree-data/envs/go2-mapless/bin/python
teacher=/root/as2w-training/runs/fall_recovery/righting-conservative-r12/model_1999.pt
"$py" fresh-holdout.py "$teacher" r12-second-teacher.jsonl 73000 & teacher_job=$!
"$py" fresh-holdout.py r12-mixed/model_100.pt r12-second-alternate.jsonl 73000 & alt_job=$!
"$py" fresh-holdout.py r12-mixed/model_159.pt r12-second-selected.jsonl 73000 & selected_job=$!
"$py" -u train_recovery_student.py assets "$teacher" r12-mixed/model_100.pt --evaluate student --report r12-mixed-alternate.jsonl
for job in "$teacher_job" "$alt_job" "$selected_job"; do wait "$job"; done
echo ALT_EXIT=0
