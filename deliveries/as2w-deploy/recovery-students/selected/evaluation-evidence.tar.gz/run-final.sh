#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export PYTHONPATH="$PWD/deps" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
py=/root/gpufree-data/envs/go2-mapless/bin/python
base=/root/as2w-training/runs/fall_recovery
jobs=()
for pair in r09:righting-streak-r09-to8000/model_7000.pt r12:righting-conservative-r12/model_1999.pt r13:righting-mixed-terrain-r13/model_1999.pt; do
    label=${pair%%:*}
    "$py" fresh-holdout.py "$base/${pair#*:}" "$label-fresh-teacher.jsonl" & jobs+=("$!")
    "$py" fresh-holdout.py "selected/recovery-$label-no-velocity.pt" "$label-fresh-student.jsonl" & jobs+=("$!")
done
"$py" export_models.py assets selected --onnx --student-checkpoints selected/*.pt >export-selected.log 2>&1
for job in "${jobs[@]}"; do wait "$job"; done
echo FINAL_EXIT=0
