import json
import sys
from pathlib import Path

import numpy as np
import torch
import train_recovery_student as run

torch.set_num_threads(1)
run.sim.ROOT = Path("assets").resolve()
contract = json.loads((run.sim.ROOT / "fall-baseline/fall-recovery-contract.json").read_text())
limits = run.sim.load_target_limits(contract)
first_seed = int(sys.argv[3]) if len(sys.argv) > 3 else 72000
state = torch.load(sys.argv[1], weights_only=True, map_location="cpu")["model_state_dict"]
with open(sys.argv[2], "w") as output, torch.inference_mode():
    for name, terrain in (("flat", None), ("slope", "slope"), ("rough", "rough")):
        for pose in run.sim.POSES:
            for seed in range(first_seed, first_seed + 8):
                model = run.sim.load_flat_model(True, True, terrain, seed)
                stress = (run.sim.sample_dynamics_stress(seed, model.nbody - 1, 16)
                          if terrain or seed % 2 else None)
                row = run.sim.evaluate(model, contract, state, seed, run.sim.POSES[pose], limits=limits,
                                       action_clip=6., wheel_scale=16., wheel_angle_period=4*np.pi,
                                       dynamics_stress=stress, terrain=terrain)
                row.update(screen=name, pose=pose, seed=seed)
                output.write(json.dumps(row)+"\n")
