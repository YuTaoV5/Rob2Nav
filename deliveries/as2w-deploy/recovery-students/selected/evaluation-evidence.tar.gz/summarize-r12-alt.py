import json
from pathlib import Path

def metrics(path, expected):
    rows = [json.loads(line) for line in Path(path).read_text().splitlines()]
    assert len(rows) == expected and all(row["valid"] for row in rows), path
    summary = {}
    for name in dict.fromkeys(row["screen"] for row in rows):
        group = [row for row in rows if row["screen"] == name]
        summary[name] = [sum(row["passed"] for row in group), len(group)]
    summary["total"] = [sum(row["passed"] for row in rows), len(rows)]
    return summary

entries = {
    "formal_240": ("r12-teacher", "r12-mixed-selected", "r12-mixed-alternate", 240),
    "new_seeds_72000": ("r12-fresh-teacher", "r12-fresh-student", "r12-mixed-model_100-fresh-alt", 96),
    "new_seeds_73000": ("r12-second-teacher", "r12-second-selected", "r12-second-alternate", 96),
}
report = {}
for label, (teacher, main, alternate, count) in entries.items():
    report[label] = {name: metrics(file + ".jsonl", count)
                     for name, file in (("teacher", teacher), ("ppo_159", main), ("ppo_100", alternate))}
    print(label, {name: results["total"] for name, results in report[label].items()})
Path("r12-alternate-delivery/comparison-r12.json").write_text(json.dumps(report, indent=2) + "\n")
