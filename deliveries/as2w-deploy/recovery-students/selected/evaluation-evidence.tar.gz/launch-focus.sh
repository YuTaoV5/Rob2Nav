#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export PYTHONPATH="$PWD/deps" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
py=/root/gpufree-data/envs/go2-mapless/bin/python
label=$1
teacher=/root/as2w-training/runs/fall_recovery/$2
"$py" -u train_recovery_student_focus.py assets "$teacher" "$label-focus.pt" --initialize-student "$label-student.pt" --focus "$3" --rounds 4
"$py" -u train_recovery_student_focus.py assets "$teacher" "$label-focus.pt" --evaluate student --report "$label-focus.jsonl"
