#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export PYTHONPATH="$PWD/deps" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
py=/root/gpufree-data/envs/go2-mapless/bin/python
label=$1
parent=$2
teacher=$3
for i in 100 159; do
    while ! test -s "$label-mixed/model_$i.pt"; do kill -0 "$parent" || exit 1; sleep 5; done
    sleep 2
    "$py" -u check-ppo-dev.py "$label-mixed/model_$i.pt" >> "$label-mixed-dev.log"
done
best=$("$py" -c 'import json,sys; rows=[json.loads(l) for l in open(sys.argv[1])]; print(max(rows,key=lambda r:(r["passed"],r["stable_s"]))["checkpoint"])' "$label-mixed-dev.log")
printf '%s\n' "$best" > "$label-mixed-best.txt"
"$py" -u train_recovery_student.py assets "$teacher" "$best" --evaluate student --report "$label-mixed-selected.jsonl"
