#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export PYTHONPATH="$PWD/deps" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
py=/root/gpufree-data/envs/go2-mapless/bin/python
label=$1
parent=$2
teacher=$3
shift 3
if [ "$label" = r09 ]; then
    for i in "$@"; do
        while ! test -s "$label-ppo/model_$i.pt"; do kill -0 "$parent" || exit 1; sleep 5; done
        sleep 2
        "$py" -u check-ppo-dev.py "$label-ppo/model_$i.pt" >> "$label-ppo-dev.log"
    done
else
    while ! grep -q 'model_599.pt' "$label-ppo-dev.log"; do kill -0 107358 || exit 1; sleep 5; done
fi
best=$("$py" -c 'import json,sys; rows=[json.loads(l) for l in open(sys.argv[1])]; print(max(rows,key=lambda r:(r["passed"],r["stable_s"]))["checkpoint"])' "$label-ppo-dev.log")
printf '%s\n' "$best" > "$label-ppo-best.txt"
"$py" -u train_recovery_student.py assets "$teacher" "$best" --evaluate student --report "$label-ppo-selected.jsonl"
