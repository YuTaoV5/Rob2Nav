import json
import sys
from pathlib import Path

import torch
import train_recovery_student as run

torch.set_num_threads(1)
run.sim.ROOT = Path("assets").resolve()
contract = json.loads((run.sim.ROOT / "fall-baseline/fall-recovery-contract.json").read_text())
limits = run.sim.load_target_limits(contract)
with torch.inference_mode():
    state = torch.load(sys.argv[1], weights_only=True, map_location="cpu")["model_state_dict"]
    assert not torch.count_nonzero(state["actor.0.weight"][:, :3])
    actor = run.numpy_actor(run.make_actor(state))
    rows = [run.rollout(contract, limits, state, pose, 61000 + trial, terrain, trial > 0, None, actor)
            for terrain in (None, "slope", "rough") for pose in run.sim.POSES for trial in range(2)]
    print(json.dumps({"checkpoint": sys.argv[1], "passed": sum(row["passed"] for row in rows),
                      "stable_s": sum(row["stable_s"] for row in rows), "trials": len(rows)}))
