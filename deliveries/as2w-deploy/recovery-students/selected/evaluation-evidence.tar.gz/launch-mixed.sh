#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export ACCEPT_EULA=Y PYTHONUNBUFFERED=1
for module in isaaclab isaaclab_tasks isaaclab_rl isaaclab_assets; do
    export PYTHONPATH="/root/isaaclab/source/$module${PYTHONPATH:+:$PYTHONPATH}"
done
exec /isaac-sim/python.sh train_mixed_ppo.py --headless --device cuda:0 \
    --num-envs 512 --iterations 160 --seed "$2" --righting-resets --wheel-scale 16 \
    --stance-height-gate --flat-domain-randomization --mixed-terrain --mirror-recovery \
    --stance-streak-reward --conservative-ppo --initialize-checkpoint "$1-student.pt" --run-dir "$1-mixed"
