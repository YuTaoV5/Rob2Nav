#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$PWD/deps"
py=/root/gpufree-data/envs/go2-mapless/bin/python
"$py" -c 'import mujoco,numpy; assert mujoco.__version__=="3.17.0"; print(mujoco.__version__,numpy.__version__)'
base=/root/as2w-training/runs/fall_recovery
run() {
    local label="$1" teacher="$base/$2" student="$PWD/$1-student.pt"
    "$py" -u train_recovery_student.py assets "$teacher" "$student" > "$label-train.log" 2>&1 &
    local fit_pid=$!
    local mode; local eval_jobs=()
    for mode in teacher masked-teacher; do
        "$py" -u train_recovery_student.py assets "$teacher" "$student" --evaluate "$mode" --report "$label-$mode.jsonl" > "$label-$mode.log" 2>&1 &
        eval_jobs+=("$!")
    done
    wait "$fit_pid"
    "$py" -u train_recovery_student.py assets "$teacher" "$student" --evaluate student --report "$label-student.jsonl" > "$label-student.log" 2>&1
    for eval_job in "${eval_jobs[@]}"; do wait "$eval_job"; done
}
run r09 righting-streak-r09-to8000/model_7000.pt & r09=$!
run r12 righting-conservative-r12/model_1999.pt & r12=$!
run r13 righting-mixed-terrain-r13/model_1999.pt & r13=$!
status=0
for job in "$r09" "$r12" "$r13"; do wait "$job" || status=1; done
echo "EXPERIMENT_EXIT=$status"
exit "$status"
