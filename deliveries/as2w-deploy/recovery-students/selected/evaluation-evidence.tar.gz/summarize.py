import json
from pathlib import Path
from statistics import median, quantiles

screens = ("standard", "confirmation", "flat-dynamics-control", "flat-dynamics-stress", "slope", "rough")
variants = ("teacher", "masked-teacher", "student", "focus", "ppo-selected", "mixed-selected")

def read(path):
    if not path.exists():
        return {}
    data = [json.loads(line) for line in path.read_text().splitlines()]
    if len(data) != 240:
        return {}
    rows = {(row["screen"], row["pose"], row["seed"]): row for row in data}
    assert len(rows) == len(data) and all(row["valid"] for row in data), path
    return rows

def compare(teacher, candidate, keys):
    vals = [candidate[key] for key in keys]
    return {
        "trials": len(keys),
        "passed": sum(row["passed"] for row in vals),
        "teacher_passed": sum(teacher[key]["passed"] for key in keys),
        "gained": sum(candidate[key]["passed"] and not teacher[key]["passed"] for key in keys),
        "lost": sum(teacher[key]["passed"] and not candidate[key]["passed"] for key in keys),
        "median_stable_s": round(median(row["stable_s"] for row in vals), 3),
        "p95_peak_impact_n": round(quantiles([row["peak_impact_n"] for row in vals], n=20)[18], 2),
        "peak_impact_ge_50n": sum(row["peak_impact_n"] >= 50 for row in vals),
    }

output = {}
for label in ("r09", "r12", "r13"):
    teacher = read(Path(f"{label}-teacher.jsonl"))
    assert teacher
    output[label] = {}
    for variant in variants:
        candidate = read(Path(f"{label}-{variant}.jsonl"))
        if not candidate:
            continue
        assert candidate.keys() == teacher.keys()
        output[label][variant] = {"total": compare(teacher, candidate, list(teacher))}
        for screen in screens:
            keys = [key for key in teacher if key[0] == screen]
            output[label][variant][screen] = compare(teacher, candidate, keys)
Path("comparison.json").write_text(json.dumps(output, indent=2) + "\n")
for label, methods in output.items():
    for variant, info in methods.items():
        print(label, variant, [info[name]["passed"] for name in ("total", *screens)],
              "gained", info["total"]["gained"], "lost", info["total"]["lost"],
              "impact95", info["total"]["p95_peak_impact_n"])
